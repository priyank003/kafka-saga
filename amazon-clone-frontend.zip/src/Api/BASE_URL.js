// export const BASE_URL = "https://www.api.gitvisual.com/api/v1";

// export const BASE_CLIENT = "https://git-visual-helpinghand03.vercel.app";

// export const BASE_URL_IMG = "https://gitvisual-production.up.railway.app/";

// export const BASE_URL_SOCKET = "https://www.api.gitvisual.com";

// export const STRIPE_PUBLISHING_KEY =
//   "pk_test_51MBluOBq5byX0xadkkf1EzjVOs9r0XmhkuakUP4ctvLZI6mIRWg4NyAKSPaP5zGI7xlhrun6mnGDg8rufTIX6i7L00Fn4K4dRN";

export const WAREHOUSE_URL = "http://localhost:8000/warehouse";
export const BASE_URL = "http://localhost:8004/api";
