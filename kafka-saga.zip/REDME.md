1.To run KafkaServer and Zookeeper we need to run the following command 
from root project directory:
```
docker-compose up
```

2.Run application:
```
npm i
nom start
```